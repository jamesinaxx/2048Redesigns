Pantone version of [2048](http://gabrielecirulli.github.io/2048/) game
========================================================================

Play here: http://git.io/pantone

[![2048 PANTONE](http://oi58.tinypic.com/1zwzv41.jpg)](http://git.io/pantone)